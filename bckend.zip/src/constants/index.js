module.exports = { 
    PORT: 5000,
    MONGODB_URL: "mongodb://127.0.0.1:27017/audax",
    JWT_KEY: "NewAuduxAPP2021",
    ZOOM_CLIENT_ID: "obpOb1aCRUGwXqQaJhBd2A",
    ZOOM_CLIENT_SECRET: "qA35hDMmh05lFAxdktSMjgr0Vt4fUokM",
    REDIRECT_URL: "http://localhost:3000/admin/dashboard",
    ZOOM_VERIFY_TOKEN: "ex2ITC8HT3-LzFVDJVwTiw"
};